@section('script')
    <script>
        alter("저는 조각 뷰의 'script' 섹션입니다.");
    </script>
    @parent
@endsection