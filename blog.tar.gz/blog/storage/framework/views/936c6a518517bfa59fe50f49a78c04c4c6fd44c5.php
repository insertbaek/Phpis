<?php $__env->startSection('script'); ?>
    <script>
        alter("저는 조각 뷰의 'script' 섹션입니다.");
    </script>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<?php $__env->stopSection(); ?>