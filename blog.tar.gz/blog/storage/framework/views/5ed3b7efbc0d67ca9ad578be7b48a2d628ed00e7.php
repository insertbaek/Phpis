<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>PHP is</title>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('script'); ?>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>