<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>PHP is</title>
    @yield('style')
</head>
<body>
    @yield('script')
    @yield('content')
</body>
</html>