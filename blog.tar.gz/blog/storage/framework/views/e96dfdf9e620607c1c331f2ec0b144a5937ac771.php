<?php $__env->startSection('style'); ?>
	<style>
		body {background: green; color: white;}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script>
		alter("저는 자식 뷰의 'script' 섹션입니다.");
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>